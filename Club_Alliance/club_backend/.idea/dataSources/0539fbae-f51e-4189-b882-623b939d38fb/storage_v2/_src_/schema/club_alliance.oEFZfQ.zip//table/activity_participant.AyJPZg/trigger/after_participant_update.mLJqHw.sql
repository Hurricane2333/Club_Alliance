create definer = root@localhost trigger after_participant_update
    after update
    on activity_participant
    for each row
BEGIN
    IF NEW.status = 'APPROVED' AND OLD.status != 'APPROVED' THEN
        UPDATE club_activity
        SET current_participants = current_participants + 1
        WHERE activity_id = NEW.activity_id;
    END IF;

    IF OLD.status = 'APPROVED' AND NEW.status != 'APPROVED' THEN
        UPDATE club_activity
        SET current_participants = current_participants - 1
        WHERE activity_id = NEW.activity_id;
    END IF;
END;

