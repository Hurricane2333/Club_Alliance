create definer = root@localhost trigger after_comment_delete
    after delete
    on post_comment
    for each row
BEGIN
    UPDATE club_post 
    SET comment_count = comment_count - 1
    WHERE post_id = OLD.post_id;
END;

