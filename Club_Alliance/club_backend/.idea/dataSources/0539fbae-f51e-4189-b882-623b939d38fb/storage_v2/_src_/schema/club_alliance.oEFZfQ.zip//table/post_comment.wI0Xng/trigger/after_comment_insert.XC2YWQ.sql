create definer = root@localhost trigger after_comment_insert
    after insert
    on post_comment
    for each row
BEGIN
    UPDATE club_post
    SET comment_count = comment_count + 1
    WHERE post_id = NEW.post_id;
END;

