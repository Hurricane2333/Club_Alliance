create definer = root@localhost trigger after_member_delete
    after delete
    on club_member
    for each row
BEGIN
    IF OLD.status = 'APPROVED' THEN
        UPDATE club
        SET current_members = current_members - 1
        WHERE club_id = OLD.club_id;
    END IF;
END;

