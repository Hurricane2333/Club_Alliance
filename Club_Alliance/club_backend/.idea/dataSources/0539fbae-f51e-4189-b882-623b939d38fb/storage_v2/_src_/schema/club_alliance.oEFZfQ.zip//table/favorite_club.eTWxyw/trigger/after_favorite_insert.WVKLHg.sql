create definer = root@localhost trigger after_favorite_insert
    after insert
    on favorite_club
    for each row
BEGIN
    UPDATE club
    SET favorite_count = favorite_count + 1
    WHERE club_id = NEW.club_id;
END;

