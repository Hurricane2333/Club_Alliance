create definer = root@localhost trigger after_member_status_update
    after update
    on club_member
    for each row
BEGIN
    IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
        UPDATE club 
        SET current_members = current_members + 1
        WHERE club_id = NEW.club_id;
    END IF;
    
    IF OLD.status = 'approved' AND NEW.status != 'approved' THEN
        UPDATE club 
        SET current_members = current_members - 1
        WHERE club_id = NEW.club_id;
    END IF;
END;

