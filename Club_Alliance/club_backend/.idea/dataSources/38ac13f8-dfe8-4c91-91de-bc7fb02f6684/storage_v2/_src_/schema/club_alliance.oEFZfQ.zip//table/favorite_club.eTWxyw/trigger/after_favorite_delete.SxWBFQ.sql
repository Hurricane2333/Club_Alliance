create definer = root@localhost trigger after_favorite_delete
    after delete
    on favorite_club
    for each row
BEGIN
    UPDATE club 
    SET favorite_count = favorite_count - 1
    WHERE club_id = OLD.club_id;
END;

