create definer = root@localhost trigger after_participant_delete
    after delete
    on activity_participant
    for each row
BEGIN
    IF OLD.status = 'approved' THEN
        UPDATE club_activity 
        SET current_participants = current_participants - 1
        WHERE activity_id = OLD.activity_id;
    END IF;
END;

